
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const db = new sqlite3.Database('./database.db');

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    guests INTEGER,
    date TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    orderText TEXT,
    address TEXT
  )`);
});

app.post('/api/bookings', (req, res) => {
  const {name, phone, guests, date} = req.body;
  db.run(
    'INSERT INTO bookings(name, phone, guests, date) VALUES(?,?,?,?)',
    [name, phone, guests, date]
  );
  res.json({success:true});
});

app.post('/api/orders', (req, res) => {
  const {name, phone, order, address} = req.body;
  db.run(
    'INSERT INTO orders(name, phone, orderText, address) VALUES(?,?,?,?)',
    [name, phone, order, address]
  );
  res.json({success:true});
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
