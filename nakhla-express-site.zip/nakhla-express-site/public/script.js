
const bookingForm = document.getElementById('bookingForm');
const deliveryForm = document.getElementById('deliveryForm');

bookingForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(bookingForm));

  await fetch('/api/bookings', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });

  const message = `حجز طاولة جديد:%0Aالاسم: ${data.name}%0Aالهاتف: ${data.phone}%0Aعدد الأشخاص: ${data.guests}%0Aالتاريخ: ${data.date}`;
  window.open(`https://wa.me/9647756340711?text=${message}`, '_blank');

  alert('تم إرسال الحجز بنجاح');
  bookingForm.reset();
});

deliveryForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(deliveryForm));

  await fetch('/api/orders', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });

  const message = `طلب توصيل جديد:%0Aالاسم: ${data.name}%0Aالهاتف: ${data.phone}%0Aالطلب: ${data.order}%0Aالعنوان: ${data.address}`;
  window.open(`https://wa.me/9647756340711?text=${message}`, '_blank');

  alert('تم إرسال الطلب بنجاح');
  deliveryForm.reset();
});
